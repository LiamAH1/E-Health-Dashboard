This is the README file for how to set up the web application

--------------------------------------------------------------
Connecting to the database
--------------------------------------------------------------
To connect to the database, locate the config file within the application
Find the file "database.php"
Set 
'hostname' =>'localhost'
'username' => 'root'
'password' => ''
'database' => 'ehealth'
'dbdriver' => 'mysqli'

*If database needs a password, enter the password into the password section to be able to gain access*

--------------------------------------------------------------
loading the SQL table structure
--------------------------------------------------------------
Find the 'SQLScript' file, open phpmyadmin, create a new database table named ehealth
Find the 'SQL' tab, and copy and paste the SQL script from the 'SQLScript' file into the field and press 'GO'

--------------------------------------------------------------
setting up admin and useage
--------------------------------------------------------------
To create Admin useage click 'Register' on the home page and enter 
Username to adminJSMP
Password to password
Email to admin@ehealth.com

To use admin, you will be redirected to the login page again and enter the details you have inserted into the database
you will be taken to the admin homepage when logging in is successful

Each button will take you to separate pages for information the admin may want to see

The admin is able to update pending submissions to accepted or rejected
admin is able to see information provided to the questionnaire to make sure it is all filled out
however, validation is in place so a questionnaire would not be submitted unless all requirements are met

The admin is also able to see charts to get a grasp of how much data the practise will have eg female to male ratio

--------------------------------------------------------------
setting up user and useage of user account
--------------------------------------------------------------
To create user account, set any username, email, password you like for the account
you will be directed to the home page

the user is able to fill out a questionnaire, view some details and update somedetails too
the user is also able to log out of the account and can log back in with the details they provided
