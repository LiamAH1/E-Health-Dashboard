<!--quesitonnaire view for the user to fill out the information to be sent to the db-->
<div class='container text-center'>
  <h1>Please fill out the E-Health questionnaire</h1>
  <div class="container">
    <p>In order to register as a new patient at the Practice you need to complete thisform. Please complete all of the relevant questions to the best of your ability and return it to one of our Practice Administration team. You will also be required to bring with you proof of your address and a photographic ID, which one of our team will photocopy.Thank you!</p>
    <p><strong>Fields marked with * are mandatory</strong></p>
  </div>
</div>

<div class="container">
  <!--function to show any validation errors where forms have no input-->
  <?php echo validation_errors();?>
  <!--form function calling the submit function for the questionnaire-->
  <?php echo form_open('questionnaire/submit');?>

  <p><strong>Your Details*</strong></p>
  <div class="form-row">
    <label>Title</label>
    <div class="col-1">
      <input type="text" class="form-control" name="title">
    </div>
    <label>Name(s)*</label>
    <div class="col">
      <input type="text" class="form-control" name="firstname">
    </div>
    <label>Surname*</label>
    <div class="col">
      <input type="text" class="form-control" name="surname">
    </div>
  </div>
  <!--next row-->
  <div class="form-row">
    <label>Date of Birth*</label>
    <div class="col-2">
      <input type="date" class="form-control" name="dob">
    </div>
    <label>Marital Status*</label>
    <div class="col">
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="marital_status" value="single" id="single">
        <label class="form-check-label" for="single">Single</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="marital_status" value="married" id="married">
        <label class="form-check-label" for="married">Married</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="marital_status" value="divorced" id="divorced">
        <label class="form-check-label" for="divorced">Divorced</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="marital_status" value="civil" id="civilpartnership">
        <label class="form-check-label" for="civil">Civil Partnership</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="marital_status" value="other" id="other">
        <label class="form-check-label" for="other">Other</label>
      </div>
    </div>
  </div>
  <!--next row-->
  <div class="form-row">
    <label>Address*</label>
    <div class="col">
      <input type="text" class="form-control" name="address">
    </div>
    <label>Postcode*</label>
    <div class="col-2">
      <input type="text" class="form-control" name="postcode">
    </div>
  </div>
  <!--next row-->
  <div class="form-row">
    <label>Mobile*</label>
    <div class="col-4">
      <input type="text" class="form-control" name="mobile">
    </div>
    <label>Home Telephone*</label>
    <div class="col">
      <input type="text" class="form-control" name="home_telephone">
    </div>
  </div>
  <!--next row-->
  <div class="form-row">
    <p>If you have supplied your mobile number, please confirm if you would be happy to receive contact via SMS messages:</p>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="SMS_YN" value="Yes" id="Yes">
      <label class="form-check-label" for="Yes">Yes</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="SMS_YN" value="No" id="No">
      <label class="form-check-label" for="No">No</label>
    </div>
  </div>
  <!--next row-->
  <div class="form-row">
    <label>Email Address*</label>
    <div class="col">
      <input type="email" class="form-control" name="email">
    </div>
    <label>Occupation</label>
    <div class="col">
      <input type="text" class="form-control" name="occupation">
    </div>
  </div>
  <!--next row-->
  <div class="form-row">
    <p>If you have supplied your email address, please confirm if you would be happy to receive contact via SMS messages:</p>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="email_yn" value="Yes" id="Yes">
      <label class="form-check-label" for="Yes">Yes</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="email_yn" value="No" id="No">
      <label class="form-check-label" for="No">No</label>
    </div>
  </div>
  <!--next row-->
  <div class="form-row">
    <p>Gender*: </p>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="gender" value="Female" id="Female">
      <label class="form-check-label" for="Female">Female</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="gender" value="Male" id="Male">
      <label class="form-check-label" for="Male">Male</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="gender" value="Non" id="Non">
      <label class="form-check-label" for="Non">Non-Binary</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="gender" value="other" id="other">
      <label class="form-check-label" for="other">In Other Way (please specify)</label>
    </div>
    <div class="col-5">
      <input type="text" class="form-control" name="gender">
    </div>
  </div>
  <!--next row-->
  <div class="form-row">
    <label>Height*</label>
    <div class="col">
      <input type="number" class="form-control" name="height">
    </div>
    <label>Weight*</label>
    <div class="col">
      <input type="number" class="form-control" name="weight">
    </div>
  </div>
</div>
<br>

<!--next of kin-->
<div class="container">
  <p><strong>Next Of Kin*</strong></p>
  <!--next row-->
  <div class="form-row">
    <label>Name:*</label>
    <div class="col">
      <input type="text" class="form-control" name="kin_name">
    </div>
    <label>Relationship*</label>
    <div class="col">
      <input type="text" class="form-control" name="kin_relationship">
    </div>
    <label>Telephone*</label>
    <div class="col">
      <input type="number" class="form-control" name="kin_telephone">
    </div>
  </div>
</div>
<br>
<!--medication-->
<!--next row-->
<div class="container">
  <p><strong>Medication*</strong></p>
  <div class="form-row">
    <p>Are you currently taking any medication?</p>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="Medication_YN" value="Yes" id="Yes">
      <label class="form-check-label" for="Yes">Yes</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="Medication_YN" value="No" id="No">
      <label class="form-check-label" for="No">No</label>
    </div>
  </div>
</div>


<div class="container">
  <p>If answered yes to the above, please list and prescribed or non-prescribed medication:</p>
  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Name of medication</th>
          <th scope="col">Dosage</th>
          <th scope="col">How often do you take it?</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><input type="text" name="Medication_1"></td>
          <td><input type="text" name="Medication_2"></td>
          <td><input type="text" name="Medication_3"></td>
        </tr>
        <tr>
          <td><input type="text" name="medication_frequency_1"></td>
          <td><input type="text" name="medication_frequency_2"></td>
          <td><input type="text" name="medication_frequency_3"></td>
        </tr>
        <tr>
          <td><input type="text" name="medication_dosage_1"></td>
          <td><input type="text" name="medication_dosage_2"></td>
          <td><input type="text" name="medication_dosage_3"></td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<!--smoking status-->
<div class="container">
  <p><strong>Smoking Status*</strong></p>
  <div class="col">
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="smoke_status" value="current" id="current">
      <label class="form-check-label" for="current">Current Smoker</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="smoke_status" value="ex" id="ex">
      <label class="form-check-label" for="ex">Ex-smoker</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="smoke_status" value="never" id="never">
      <label class="form-check-label" for="neversmoked">Never smoked</label>
    </div>
    <p>If you are a current smoker:</p>
  </div>
  <div class="col">
    <p>What do you smoke?</p>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="smoke_type" value="cigarettes" id="cigarettes">
      <label class="form-check-label" for="current">Cigarettes</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="smoke_type" value="cigars" id="cigars">
      <label class="form-check-label" for="cigars">Cigars</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="smoke_type" value="e-cigs" id="e-cigs">
      <label class="form-check-label" for="e-cigs">E-Cigarettes</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="smoke_type" value="pipe" id="pipe">
      <label class="form-check-label" for="pipe">Pipe</label>
    </div>
  </div>
  <div class="form-row">
    <label>How old were you when you started smoking?(years)</label>
    <div class="col-3">
      <input type="number" class="form-control" placeholder="years" name="start_smoking">
    </div>
  </div>
  <label>Would you like more information about support to help you quit smoking?</label>
  <div class="form-check form-check-inline">
    <input class="form-check-input" type="radio" name="quit_smoking" value="yes">
    <label class="form-check-label" for="current">Yes</label>
    <input class="form-check-input" type="radio" name="quit_smoking" value="no">
    <label class="form-check-label" for="current">No</label>
  </div>

</div>
<br>

<!--Audit-->
<div class="container">
  <p><strong>Alcohol Use(AUDIT)</strong></p>
  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Questions</th>
          <th scope="col-1">0</th>
          <th scope="col-1">1</th>
          <th scope="col-1">2</th>
          <th scope="col-1">3</th>
          <th scope="col-1">4</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>How often do you have a drink containing alcohol?</td>
          <td><input class="form-check-input" type="radio" name="audit1" value="0" id="0">Never</td>
          <td><input class="form-check-input" type="radio" name="audit1" value="1" id="1">Monthly or less</td>
          <td><input class="form-check-input" type="radio" name="audit1" value="2" id="2">2-4 times per month</td>
          <td><input class="form-check-input" type="radio" name="audit1" value="3" id="3">2-3 times per month</td>
          <td><input class="form-check-input" type="radio" name="audit1" value="4" id="4">4+ times per month</td>
        </tr>
        <tr>
          <td>How many units of alcohol do you drink on a typical <br>day when you are drinking</td>
          <td><input class="form-check-input" type="radio" name="audit2" value="0" id="0">1-2</td>
          <td><input class="form-check-input" type="radio" name="audit2" value="1" id="1">3-4</td>
          <td><input class="form-check-input" type="radio" name="audit2" value="2" id="2">5-6</td>
          <td><input class="form-check-input" type="radio" name="audit2" value="3" id="3">7-8</td>
          <td><input class="form-check-input" type="radio" name="audit2" value="4" id="4">10+</td>
        </tr>
        <tr>
          <td>How often have you had 6 or more units if female or<br>8 if you are male on a single occasion in the last year</td>
          <td><input class="form-check-input" type="radio" name="audit3" value="0" id="0">Never</td>
          <td><input class="form-check-input" type="radio" name="audit3" value="1" id="1">Less than <br>monthly</td>
          <td><input class="form-check-input" type="radio" name="audit3" value="2" id="2">Monthly</td>
          <td><input class="form-check-input" type="radio" name="audit3" value="3" id="3">Weekly</td>
          <td><input class="form-check-input" type="radio" name="audit3" value="4" id="4">Daily or <br>almost daily</td>
        </tr>
        <tr>
          <td>How often during the last year have you found that<br> you were not able to stop drinking once you had started?</td>
          <td><input class="form-check-input" type="radio" name="audit4" value="0" id="0">Never</td>
          <td><input class="form-check-input" type="radio" name="audit4" value="1" id="1">Less than <br>monthly</td>
          <td><input class="form-check-input" type="radio" name="audit4" value="2" id="2">Monthly</td>
          <td><input class="form-check-input" type="radio" name="audit4" value="3" id="3">Weekly</td>
          <td><input class="form-check-input" type="radio" name="audit3" value="4" id="4">Daily or <br>almost daily</td>
        </tr>
        <tr>
          <td>How often during the last year have you failed to do what was normally <br>expected from you because you were drinking?</td>
          <td><input class="form-check-input" type="radio" name="audit5" value="0" id="0">Never</td>
          <td><input class="form-check-input" type="radio" name="audit5" value="1" id="1">Less than <br>monthly</td>
          <td><input class="form-check-input" type="radio" name="audit5" value="2" id="2">Monthly</td>
          <td><input class="form-check-input" type="radio" name="audit5" value="3" id="3">Weekly</td>
          <td><input class="form-check-input" type="radio" name="audit3" value="4" id="4">Daily or <br>almost daily</td>
        </tr>
        <tr>
          <td>How often during the last year have you needed<br> an alcoholic drink in the morning to get yourself going after<br> a heavy drinking session?</td>
          <td><input class="form-check-input" type="radio" name="audit6" value="0" id="0">Never</td>
          <td><input class="form-check-input" type="radio" name="audit6" value="1" id="1">Less than <br>monthly</td>
          <td><input class="form-check-input" type="radio" name="audit6" value="2" id="2">Monthly</td>
          <td><input class="form-check-input" type="radio" name="audit6" value="3" id="3">Weekly</td>
          <td><input class="form-check-input" type="radio" name="audit3" value="4" id="4">Daily or <br>almost daily</td>
        </tr>
        <tr>
          <td>How often during the last year have you had a feeling of guilt or<br>remorse after drinking?</td>
          <td><input class="form-check-input" type="radio" name="audit7" value="0" id="0">Never</td>
          <td><input class="form-check-input" type="radio" name="audit7" value="1" id="1">Less than <br>monthly</td>
          <td><input class="form-check-input" type="radio" name="audit7" value="2" id="2">Monthly</td>
          <td><input class="form-check-input" type="radio" name="audit7" value="3" id="3">Weekly</td>
          <td><input class="form-check-input" type="radio" name="audit3" value="4" id="4">Daily or <br>almost daily</td>
        </tr>
        <tr>
          <td>How often during the last year have  you been <br>unable to remember what happened the night before <br>because you had been drinking?</td>
          <td><input class="form-check-input" type="radio" name="audit8" value="0" id="0">Never</td>
          <td><input class="form-check-input" type="radio" name="audit8" value="1" id="1">Less than <br>monthly</td>
          <td><input class="form-check-input" type="radio" name="audit8" value="2" id="2">Monthly</td>
          <td><input class="form-check-input" type="radio" name="audit8" value="3" id="3">Weekly</td>
          <td><input class="form-check-input" type="radio" name="audit3" value="4" id="4">Daily or <br>almost daily</td>
        </tr>
        <tr>
          <td>Have you or somebody else been injured as a result of your drinking?</td>
          <td><input class="form-check-input" type="radio" name="audit9" value="0" id="0">No</td>
          <td></td>
          <td><input class="form-check-input" type="radio" name="audit9" value="2" id="2">Yes, but not in<br> the last year</td>
          <td></td>
          <td><input class="form-check-input" type="radio" name="audit9" value="4" id="4">Yes, but during<br> the last year</td>
        </tr>
        <tr>
          <td>Has a relative or friend, doctor or other health <br> worker been concerned about your drinking or suggester that you cut down?</td>
          <td><input class="form-check-input" type="radio" name="audit10" value="0" id="0">No</td>
          <td></td>
          <td><input class="form-check-input" type="radio" name="audit10" value="2" id="2">Yes, but not in<br> the last year</td>
          <td></td>
          <td><input class="form-check-input" type="radio" name="audit10" value="4" id="4">Yes, but during <br>the last year</td>
        </tr>
      </tbody>
    </table>
  </div>
</div>
</div>

<!--family history-->
<div class="container">
  <p><strong>Family Medical History</strong></p>
  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Condition</th>
          <th scope="col">Affected</th>
          <th scope="col">Which family member</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Heart Disease(heart attacks, angina)</td>
          <td><div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="has_heart_disease" value="Yes" id="Yes">
            <label class="form-check-label" for="Yes">Yes</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="has_heart_disease" value="No" id="No">
            <label class="form-check-label" for="No">No</label>
          </div></td>
          <td><input type="text" name="other"></td>
        </tr>
        <tr>
          <td>Cancer</td>
          <td><div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="has_cancer" value="Yes" id="Yes">
            <label class="form-check-label" for="Yes">Yes</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="has_cancer" value="No" id="No">
            <label class="form-check-label" for="No">No</label>
          </div></td>
          <td><input type="text" name="other"></td>
        </tr>
        <tr>
          <td>Stroke</td>
          <td><div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="has_stroke" value="Yes" id="Yes">
            <label class="form-check-label" for="Yes">Yes</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="has_stroke" value="No" id="No">
            <label class="form-check-label" for="No">No</label>
          </div></td>
          <td><input type="text" name="other"></td>
        </tr>
        <tr>
          <td>Other(please specify)</td>
          <td><div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="has_other" value="Yes" id="Yes">
            <label class="form-check-label" for="Yes">Yes</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="has_other" value="No" id="No">
            <label class="form-check-label" for="No">No</label>
          </div></td>
          <td><input type="text" name="other"></td>
        </tr>
      </tbody>
    </table>
  </div>
</div>


<!--allergies-->
<div class="container">
  <p><strong>Allergies*</strong></p>
  <div class="form-row">
    <p>Are you allergic to any medicines, substances or foods ?</p>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="allergies" value="Yes" id="Yes">
      <label class="form-check-label" for="Yes">Yes</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="allergies" value="No" id="No">
      <label class="form-check-label" for="No">No</label>
    </div>
  </div>
  <div class="form-group">
    <label for="exampleTextarea">If yes, please give details</label>
    <textarea class="form-control" id="allergiesText" rows="3" name="allergy_details"></textarea>
  </div>
</div>

<!--lifestyle-->
<div class="container">
  <p><strong>Lifestyle</strong></p>
  <div class="form-row">
    <p>Do you take regular exercise?</p>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="exercise" value="Yes" id="Yes">
      <label class="form-check-label" for="Yes">Yes</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="exercise" value="No" id="No">
      <label class="form-check-label" for="No">No</label>
    </div>
  </div>
  <div class="form-row">
    <label>How long do you exercise for in one session?</label>
    <div class="col-3">
      <input type="number" class="form-control" placeholder="minutes" name="exercise_minutes">
    </div>
  </div>
  <div class="form-row">    
    <label>How often do you exercise in a typical week?</label>
    <div class="col-3">
      <input type="number" class="form-control" placeholder="days" name="exercise_days">
    </div>
  </div>

  <p>Which one of the following best describes your poor diet?</p>
  <div class="form-row">
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="diet" id="good" value="good">
      <label class="form-check-label" for="good">Good</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="diet" id="average" value="average">
      <label class="form-check-label" for="average">Average</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="diet" id="poor" value="poor">
      <label class="form-check-label" for="poor">Poor</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="diet" id="vegetarian" value="vegetarian">
      <label class="form-check-label" for="vegetarian">Vegetarian</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="diet" id="vegan" value="vegan">
      <label class="form-check-label" for="vegan">Vegan</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="diet" id="lowfat" value="lowfat">
      <label class="form-check-label" for="lowfat">Low Fat</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="radio" name="diet" id="lowsalt" value="lowsalt">
      <label class="form-check-label" for="lowsalt">Low Salt</label>
    </div>
  </div>
</div>

<!--Declaration-->
<div class="container">
  <p><strong>Declaration*</strong></p>
  <p>I confirm that the given information is correct to the best of my knowledge</p>
  <div class="form-row">
    <label>Signed*</label>
    <div class="col-3">
      <input type="text" class="form-control">
    </div>
    <label>Date*</label>
    <div class="col-3">
      <input type="text" class="form-control">
    </div>
  </div> 
  <br> 
  <div class="form-group">
    <input type="submit" name="create" value="Submit" class="btn btn-info">
  </div>
</div>
<br>
<hr>

<?php echo form_close();?>
<!--office use-->
<div class="container bg-light">
  <p><strong>FOR OFFICE USE ONLY</strong></p>

  <br> 
  <div class="form-check form-check-inline">
    <input class="form-check-input" type="checkbox" id="accept" value="accept" disabled>
    <label class="form-check-label" for="accept">Application Accepted</label>
  </div>
  <div class="form-check form-check-inline">
    <input class="form-check-input" type="checkbox" id="reject" value="reject" disabled>
    <label class="form-check-label" for="reject">Application Rejected</label>
  </div>
  <br>

  <div class="form-row">
    <label>Audit Score</label>
    <div class="col-3">
      <input type="text" class="form-control" disabled>
    </div>
  </div> 
  <br> 
  <div class="form-row">
    <label>Assigned to GP</label>
    <div class="col-3">
      <input type="text" class="form-control" disabled>
    </div>
    <label>Patient ID</label>
    <div class="col-3">
      <input type="text" class="form-control" disabled>
    </div>
  </div> 
  <br>
  <div class="form-row">
    <label>Processed by</label>
    <div class="col-3">
      <input type="text" class="form-control" disabled>
    </div>
    <label>Date*</label>
    <div class="col-3">
      <input type="text" class="form-control" disabled>
    </div>
  </div> 
  <br> 
</div>