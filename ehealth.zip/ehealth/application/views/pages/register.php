<!--registration form for the user -->
<div class="col-xs-1" align="center">
	<h1>E-Health registration form</h1>
	<h3>Please create a username and password to continue</h3>
</div>



<div class="container">
	<!--showing any validation errors-->
	<?php echo validation_errors();?>
	<!--calling register route-->
	<?php echo form_open('users/register'); ?>
	<div class="form-group">
		<label for="username">Create username</label>
		<input type="text" class="form-control" name="username" placeholder="Username" autocomplete="off" required>
	</div>
	<div class="form-group">
		<label for="email">Email</label>
		<input type="email" class="form-control" name="email" placeholder="Email" autocomplete="off" required>
	</div>
	<div class="form-group">
		<label for="username">Password</label>
		<input type="password" class="form-control" name="password" placeholder="Password" required>
	</div>
	<div class="form-group">
		<label for="username">Confirm Password</label>
		<input type="password" class="form-control" name="password2" placeholder="Confirm Password" required>
	</div>
	<button type="submit" class="btn btn-primary">Register</button>
</div>
<?echo form_close();?>

