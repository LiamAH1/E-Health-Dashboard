<!--form for the login for the user-->
<div class="col-xs-1" align="center">
	<h1><?php echo "Welcome to the E-Health Portal";?></h1>
	<h3>Please log in below</h3>
</div>

<!-- login form-->
<div class="container">
	<!--showing any form validation errors-->
	<?php echo validation_errors();?>
	<!--form open function to call the login route-->
	<?php echo form_open('users/login'); ?>
	<div class="form-group">
		<label for="username">Enter Username</label>
		<input type="text" class="form-control" name="username" placeholder="Username" required autofocus autocomplete="off">
	</div>
	<div class="form-group">
		<label for="username">Enter Password</label>
		<input type="password" class="form-control" name="password" placeholder="Password" required autofocus>
	</div>
	<button type="submit" class="btn btn-primary">Login</button>
</div>
<?php echo form_close();?>


<!--registration button-->

<form action="<?php echo base_url('users/register');?>">
	<div class="container">
		<p>If not a current user, please register here</p>
		<button  type="submit" class="btn btn-primary" >Register</button>
	</div>
</form>

