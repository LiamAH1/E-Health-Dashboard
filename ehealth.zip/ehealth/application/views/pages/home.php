<!--Home page with simple text-->
<div class="container text-center" >
<p>Welcome to the E-Health portal where you will need to fill out a questionnaire for us to get a better feel for who you are. You will also be able to edit some information you will be providing for us.</p>
</div>