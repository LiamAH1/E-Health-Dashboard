<!--Details page loading the view-->
<div class='container text-center'>
  <h1><?php echo "Your details";?></h1>
</div>
<form>
  <div class="container">
    <p><strong>Your Details*</strong></p>
    <div class="form-row">
      <label>Title</label>
      <div class="col-1">
        <input type="text" class="form-control">
      </div>
      <label>Name(s)*</label>
      <div class="col">
        <input type="text" class="form-control">
      </div>
      <label>Surname*</label>
      <div class="col">
        <input type="text" class="form-control">
      </div>
    </div>
    <!--next row-->
    <div class="form-row">
      <label>Date of Birth*</label>
      <div class="col-2">
        <input type="text" class="form-control">
      </div>
      <label>Marital Status*</label>
      <div class="col">
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="inlineRadioOptions" value="single" id="single">
          <label class="form-check-label" for="single">Single</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="inlineRadioOptions" value="married" id="married">
          <label class="form-check-label" for="married">Married</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="inlineRadioOptions" value="divorced" id="divorced">
          <label class="form-check-label" for="divorced">Divorced</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="inlineRadioOptions" value="civil" id="civilpartnership">
          <label class="form-check-label" for="civil">Civil Partnership</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="inlineRadioOptions" value="other" id="other">
          <label class="form-check-label" for="other">Other</label>
        </div>
      </div>
    </div>
    <!--next row-->
    <div class="form-row">
      <label>Address*</label>
      <div class="col">
        <input type="text" class="form-control">
      </div>
      <label>Postcode*</label>
      <div class="col-2">
        <input type="text" class="form-control">
      </div>
    </div>
    <!--next row-->
    <div class="form-row">
      <label>Mobile*</label>
      <div class="col-4">
        <input type="text" class="form-control">
      </div>
      <label>Home Telephone*</label>
      <div class="col">
        <input type="text" class="form-control">
      </div>
    </div>
    <!--next row-->
    <div class="form-row">
      <p>If you have supplied your mobile number, please confirm if you would be happy to receive contact via SMS messages:</p>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="inlineRadioOptions2" value="Yes" id="Yes">
        <label class="form-check-label" for="Yes">Yes</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="inlineRadioOptions2" value="No" id="No">
        <label class="form-check-label" for="No">No</label>
      </div>
    </div>
    <!--next row-->
    <div class="form-row">
      <label>Email Address*</label>
      <div class="col">
        <input type="text" class="form-control">
      </div>
      <label>Occupation</label>
      <div class="col">
        <input type="text" class="form-control">
      </div>
    </div>
    <!--next row-->
    <div class="form-row">
      <p>If you have supplied your email address, please confirm if you would be happy to receive contact via SMS messages:</p>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="inlineRadioOptions3" value="Yes" id="Yes">
        <label class="form-check-label" for="Yes">Yes</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="inlineRadioOptions3" value="No" id="No">
        <label class="form-check-label" for="No">No</label>
      </div>
    </div>
    <!--next row-->
    <div class="form-row">
      <p>Gender*: </p>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="inlineRadioOptions4" value="Yes" id="Yes">
        <label class="form-check-label" for="Yes">Female</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="inlineRadioOptions4" value="No" id="No">
        <label class="form-check-label" for="No">Male</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="inlineRadioOptions4" value="Non" id="Non">
        <label class="form-check-label" for="Non">Non-Binary</label>
      </div>
      <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="inlineRadioOptions4" value="other" id="other">
        <label class="form-check-label" for="other">In Other Way (please specify)</label>
      </div>
      <div class="col-5">
        <input type="text" class="form-control">
      </div>
    </div>
    <!--next row-->
    <div class="form-row">
      <label>Height*</label>
      <div class="col">
        <input type="text" class="form-control">
      </div>
      <label>Weight*</label>
      <div class="col">
        <input type="text" class="form-control">
      </div>
    </div>
  </div>
  <br>

  <!--next of kin-->
  <div class="container">
    <p><strong>Next Of Kin*</strong></p>
    <!--next row-->
    <div class="form-row">
      <label>Name:*</label>
      <div class="col">
        <input type="text" class="form-control">
      </div>
      <label>Relationship*</label>
      <div class="col">
        <input type="text" class="form-control">
      </div>
      <label>Telephone*</label>
      <div class="col">
        <input type="text" class="form-control">
      </div>
    </div>
    <br>
    <button type="submit" class="btn btn-primary">Update</button>
  </div>
</form>