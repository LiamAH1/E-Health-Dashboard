<!--admin homepage to go to different parts of the admin area-->
<div class="d-flex justify-content-center">
<form action="<?php echo base_url('admin/dashboard');?>">
	<div class="container">
		<p>Click for dashboard</p>
		<button  type="submit" class="btn btn-primary" >Dashboard</button>
	</div>
</form>
<form action="<?php echo base_url('admin/questionnaire');?>">
	<div class="container">
		<p>Click for list of questionnaire</p>
		<button  type="submit" class="btn btn-primary" >Questionnaires</button>
	</div>
</form>


<form action="<?php echo base_url('users/login');?>">
	<div class="container">
		<p>Or logoff</p>
		<button  type="submit" class="btn btn-primary" >Log off</button>
	</div>
</form>
</div>