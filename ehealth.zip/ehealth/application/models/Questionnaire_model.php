<?php
/*
Below is the questionnaire model where all of the inserting of the user data will be processed to the database.
*/
defined('BASEPATH') OR exit('No direct script access allowed');
class Questionnaire_model extends CI_model
{
	public function __construct(){
		$this->load->database();
	}
		//inseting user data
	public function userInsert($user_id, $userData){
	//keeping user information as update
		$this->db->where('GUID', $user_id);
		$this->db->update('users', $userData);		
	}
	//inserting smoking data
	public function smokeInsert($user_id, $smokingData){
		$this->db->where('userid', $user_id);
		$this->db->insert('smoking', $smokingData);
	}
	//inserting medication data
	public function medicalInsert($user_id, $medicationData){
		$this->db->where('userid', $user_id);
		$this->db->insert('medication', $medicationData);
	}
	//inserting medical history data
	public function medicalHistInsert($user_id, $medicalHistData){
		$this->db->where('userid', $user_id);
		$this->db->insert('medical_history', $medicalHistData);
	}
	//inserting lifestyle data
	public function lifestyleInsert($user_id, $lifestyleData){
		$this->db->where('userid', $user_id);
		$this->db->insert('lifestyle', $lifestyleData);
	}
	//inserting allergy data
	public function allergyInsert($user_id, $allergyData){
		$this->db->where('userid', $user_id);
		$this->db->insert('allergies', $allergyData);
	}	
}