<?php
	/**
	 * Admin model for the admins to see all of the collected data from approved questionnaire submissions
	 */
	class Admin_model extends CI_model
	{

		public function dashboard(){
			
		}
	}