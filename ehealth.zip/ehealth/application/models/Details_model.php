<?php
/**
 * Below is the details model that would collect the user data the user has input to view in the table 
 for them to update
 */
class Details_model extends CI_model
{
	
	public function __construct()
	{
		
	}
}