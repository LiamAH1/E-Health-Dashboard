<?php
/**
 * This model has all of the user registration functions within
 */
defined('BASEPATH') OR exit('No direct script access allowed');
class User_model extends CI_model{
	
	public function __construct(){
		parent:: __construct();
	}


	//login function
	public function login($username, $password){
		//Get the GUID, status 

		//validation
		$this->db->select('GUID, status');
		$this->db->from('users');
		$this->db->where('username', $username);
		$this->db->where('password', $password);
		$result = $this->db->get();

		return $result->row_array();
	}


	//register function
	public function register($encrypt){
		//user data
		$data = array(
			'username' =>$this->input->post('username'),
			'email' =>$this->input->post('email'),
			'password' => $encrypt
		);

		return $this->db->insert('users', $data);
	}

	//checking if a username is already in use
	public function userExists($username){
		$query =$this->db->get_where('users', array('username' => $username));
		if(empty($query->row_array())){
			return true;
		}else
		{
			return false;
		}
	}

	//checking an email is already in use
	public function emailExists($email){
		$query =$this->db->get_where('users', array('email' => $email));
		if(empty($query->row_array())){
			return true;
		}else
		{
			return false;
		}
	}
}