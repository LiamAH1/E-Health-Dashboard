<?php
/**
 * This controller handles all of the user login, registration, logging off, checking user email exists and if a username exists. Form validation is in the register and login forms to make sure the
 user inputs data needed
 */

 defined('BASEPATH') OR exit('No direct script access allowed');
 class Users extends CI_Controller
 {

 	public function __construct()
 	{
 		parent:: __construct();
 	}

	/*
	Below is the user registration function where it sets rules such as required to make sure the user inserts information. 
	The rules also use callbacks to check if a username is already in use aswell as an email.
	*/
	//user registration
	public function register(){
		/*
		Setting rules for the input fileds for registration. 
		matches->makes sure the confirm password matches the original password input
		callback_->calling back two custom functions to check if the input email or username is already being used in the db
		*/
		$this->form_validation->set_rules('username', 'Username', 'required|callback_userExists');
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|callback_emailExists');
		$this->form_validation->set_rules('password2', 'Confirm password', 'matches[password]');

		//if the form has not run or it is not complete, loads the view
		if($this->form_validation->run() === FALSE){
			$this->load->view('templates/index_header');
			$this->load->view('pages/register');
			$this->load->view('templates/index_footer');
		}else{
			//if it is successful, calls the model and the functions
			/*$encrypt takes the input password and hashes it using the md5 function built into codeigniter
			and passes it to the User_model model using the register function
			*/
			$encrypt = md5($this->input->post('password'));
			$this->User_model->register($encrypt);
			redirect('home');
		}
	}

	//checking if a username already exists
	public function userExists($username){
		//setting message to tell user username is already in use
		$this->form_validation->set_message('userExists', 'That username is taken, please try another');
		if($this->User_model->userExists($username)){
			return true;
		}else{
			return false;
		}
	}

	//checking if an email is already in use
	public function emailExists($email){
		//setting message to tell use email is already in use
		$this->form_validation->set_message('emailExists', 'That email is already in use, please try another');
		if($this->User_model->emailExists($email)){
			return true;
		}else{
			return false;
		}
	}

	/*
	Below is all of the lo
	*/
	//user login function
	public function login(){
		//setting rules for forms
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		//checking if the form_validation has run or not
		if($this->form_validation->run() === FALSE){
			$this->load->view('templates/index_header');
			$this->load->view('pages/welcome');
			$this->load->view('templates/index_footer');
		}else{
			//getting the username and password from the db
			$username = $this->input->post('username');
			$password = md5($this->input->post('password'));
			//loading the User_model login function
			$userDetails = $this->User_model->login($username, $password);
			/*if the details are not empty, set the sesstion to the current userid and
			set the logged in session to true for the logout function below and to stop users from accessing
			other pages when they are not logged in
			*/
			if($userDetails != ""){
				$this->session->set_userdata('userid',$userDetails['GUID']);
				$this->session->set_userdata('logged_in', TRUE);
				//if username is == to admin, redirect to admin section
				if($username == "adminJSMP"){
					redirect('admin/index');
				}else{
					//if not admin, redirect to home
					redirect('home');
				}
			}else{
				//if neither, redirect to login
				redirect('users/login');
			}
		}
	}

	//user logging off
	public function logout(){
		//unsetting all the user data
		//$this->session->unset_userdata('userid',$userDetails['GUID']);
		$this->session->unset_userdata('logged_in');
		//redirecting to user page
		$this->session->sess_destroy();

		redirect('users/login', 'refresh');
	}
}
