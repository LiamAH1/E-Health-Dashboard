 <?php
 /*
 Below is the questionnaire class where all of the form validation occurs and data insert into the database itself.
 */
 defined('BASEPATH') OR exit('No direct script access allowed');
 class Questionnaire extends CI_Controller {
 	public function __construct(){
 		parent:: __construct();
 		$this->load->database();
 		

 	}

 	//below is the form validation for the submt method
 	public function submit(){

 		/*
 		Each validation has its own set of rules, ranging from only allowing alpha characters or max lengths of text allowed,
		It also makes some of the inputs required where rhe user has to input information. The trim rule removes any white space from the beginning and end of a text field.

		rules used
		Trim->removes whitespace
		Required->requires the user to input data
		Alpha->only allows letters of the alphabet
		Alpha_numeric_spaces->allows spaces, numbers and letters
		exact_length->only accepts the correct length of numbers
		max_length->only allows a certain amount of numbers and letters
 		*/
 		//form validation below
 		
 		$this->form_validation->set_rules("firstname", "Firstname","trim|required|alpha");
 		$this->form_validation->set_rules("surname", "Surname","trim|required|alpha");
 		$this->form_validation->set_rules("dob", "dob","required");
 		$this->form_validation->set_rules("title", "Title","trim|required|alpha|max_length[4]");
 		$this->form_validation->set_rules("marital_status", "Marital Status","required");
 		$this->form_validation->set_rules("address", "Address","trim|required|alpha_numeric_spaces");
 		$this->form_validation->set_rules("postcode", "Postcode","trim|required|alpha_numeric_spaces|max_length[8]");
 		$this->form_validation->set_rules("mobile", "Mobile","trim|required|numeric|exact_length[11]");
 		$this->form_validation->set_rules("home_telephone", "Home Telephone","trim|required|numeric|exact_length[11]");
 		$this->form_validation->set_rules("SMS_YN", "SMS Yes No","required");
 		$this->form_validation->set_rules("occupation", "Occupation","trim|required|alpha");
 		$this->form_validation->set_rules("email_yn", "Email YN","required");
 		$this->form_validation->set_rules("gender", "Gender");
 		$this->form_validation->set_rules("height", "Height","trim|required|numeric");
 		$this->form_validation->set_rules("weight", "Weight","trim|required|numeric");
 		$this->form_validation->set_rules("kin_name", "Kin name","trim|required|alpha");
 		$this->form_validation->set_rules("kin_relationship", "Kin relationship","trim|required|alpha");
 		$this->form_validation->set_rules("kin_telephone", "Kin telephone","trim|required|numeric|exact_length[11]");
 		
 		
 		//smoking
 		$this->form_validation->set_rules("smoke_status", "Smoking status", "required");
 		$this->form_validation->set_rules("smoke_type", "Smoke Type","required");
 		$this->form_validation->set_rules("start_smoking", "Start Smoking","trim|required|numeric");
 		$this->form_validation->set_rules("quit_smoking", "Quit Smoking","required");
 		
 		
 		//medication
 		$this->form_validation->set_rules("Medication_YN", "Medication yn","required");
 		$this->form_validation->set_rules("Medication_1", "med1","alpha");
 		$this->form_validation->set_rules("Medication_2", "med2","alpha");
 		$this->form_validation->set_rules("Medication_3", "med3","alpha");
 		$this->form_validation->set_rules("medication_frequency_1", "medication_frequency_1","trim|alpha_numeric_spaces");
 		$this->form_validation->set_rules("medication_frequency_2", "medication_frequency_1","trim|alpha_numeric_spaces");
 		$this->form_validation->set_rules("medication_frequency_3", "medication_frequency_1","trim|alpha_numeric_spaces");
 		$this->form_validation->set_rules("medication_dosage_1", "medication_dosage_1","trim|alpha_numeric_spaces");
 		$this->form_validation->set_rules("medication_dosage_1", "medication_dosage_2","trim|alpha_numeric_spaces");
 		$this->form_validation->set_rules("medication_dosage_1", "medication_dosage_3","trim|alpha_numeric_spaces");

		//medical history
 		$this->form_validation->set_rules("has_cancer", "Has cancer");
 		$this->form_validation->set_rules("has_heart_disease", "Heart disease");
 		$this->form_validation->set_rules("has_stroke", "Has Stroke");
 		$this->form_validation->set_rules("has_other", "Has Other");

		//lifestyle
 		$this->form_validation->set_rules("exercise", "Exercise");
 		$this->form_validation->set_rules("exercise_minutes", "Exercise minutes", "trim|numeric");
 		$this->form_validation->set_rules("exercise_days", "Exercise Days", "trim|numeric");
 		$this->form_validation->set_rules("diet", "diet");

		//allergies
 		$this->form_validation->set_rules("allergy_details", "Allergy details","trim|max_length[150]");

 		//checking if user is logged in, if not, redirect to login page to stop unorthorised access
 		if(!$this->session->userdata('logged_in')){
 			redirect('users/login');
 		}

 		//if the form has not run or it is not complete, loads the view
 		if($this->form_validation->run()===FALSE){
 			//loading views
 			$this->load->view('templates/header');
 			$this->load->view('pages/questionnaire');
 			$this->load->view('templates/footer');
 		}else{
 		//if it is successful, calls the model and the functions
 			//setting $user_id to the current session userid
 			$user_id = $this->session->userdata('userid');
 			//inserting userData information
 			$userData = array(
 				'firstname' =>$this->input->post('firstname'),
 				'surname' =>$this->input->post('surname'),
 				'dob' =>$this->input->post('dob'),
 				'title' =>$this->input->post('title'),
 				'marital_status' =>$this->input->post('marital_status'),
 				'address' =>$this->input->post('address'),
 				'postcode' =>$this->input->post('postcode'),
 				'mobile' =>$this->input->post('mobile'),
 				'home_telephone' =>$this->input->post('home_telephone'),
 				'SMS_YN' =>$this->input->post('SMS_YN'),
 				'occupation' =>$this->input->post('occupation'),
 				'email_yn' =>$this->input->post('email_yn'),
 				'gender' =>$this->input->post('gender'),
 				'height' =>$this->input->post('height'),
 				'weight' =>$this->input->post('weight'),
 				'kin_name' =>$this->input->post('kin_name'),
 				'kin_relationship' =>$this->input->post('kin_relationship'),
 				'kin_telephone' =>$this->input->post('kin_telephone')
 			);
 			$this->Questionnaire_model->userInsert($user_id, $userData);
 			//inserting smokingData
 			$smokingData = array(
 				'userid' => $user_id,
 				'smoke_status' =>$this->input->post('smoke_status'),
 				'smoke_type' =>$this->input->post('smoke_type'),
 				'start_smoking' =>$this->input->post('start_smoking'),
 				'quit_smoking' =>$this->input->post('quit_smoking')
 			);
 			$this->Questionnaire_model->smokeInsert($user_id, $smokingData);
 			//inserting medicationData
 			$medicationData = array(
 				'userid' => $user_id,
 				'Medication_YN' =>$this->input->post('Medication_YN', 'Medicaion yes no', 'required'),
 				'Medication_1' =>$this->input->post('Medication_1'),
 				'Medication_2' =>$this->input->post('Medication_2'),
 				'Medication_3' =>$this->input->post('Medication_3'),
 				'medication_frequency_1' =>$this->input->post('medication_frequency_1'),
 				'medication_frequency_2' =>$this->input->post('medication_frequency_2'),
 				'medication_frequency_3' =>$this->input->post('medication_frequency_3'),
 				'medication_dosage_1' =>$this->input->post('medication_dosage_1'),
 				'medication_dosage_2' =>$this->input->post('medication_dosage_2'),
 				'medication_frequency_3' =>$this->input->post('medication_dosage_3')
 			);
 			$this->Questionnaire_model->medicalInsert($user_id, $medicationData);
 			//inserting medicalHistDay
 			$medicalHistData = array(
 				'userid' => $user_id,
 				'has_cancer' =>$this->input->post('has_cancer'),
 				'has_heart_disease' =>$this->input->post('has_heart_disease'),
 				'has_stroke' =>$this->input->post('has_stroke'),
 				'has_other' =>$this->input->post('has_other')

 			);
 			$this->Questionnaire_model->medicalHistInsert($user_id, $medicalHistData);
 			//inserting lifestyleData
 			$lifestyleData = array(
 				'userid' => $user_id,
 				'exercise' =>$this->input->post('exercise'),
 				'exercise_days' =>$this->input->post('exercise_days'),
 				'exercise_minutes' =>$this->input->post('exercise_minutes'),
 				'diet' =>$this->input->post('diet')
 			);
 			$this->Questionnaire_model->lifestyleInsert($user_id, $lifestyleData);
 			//inserting allergyData
 			$allergyData = array(
 				'userid' => $user_id,
 				'allergy_details' =>$this->input->post('allergy_details')
 			);
 			$this->Questionnaire_model->allergyInsert($user_id, $allergyData);

 			//redirects to home page when it is successful
 			redirect('home');
 		}

 	}	
 }


 

