<?php
/*
Below are all the functions for the admin views. from here, the functions will allow the admin to view a list of submitted applications and either accept of reject them. the user will also be able to view the submitted questionnaire itself to see if all the data inserted is correctly input. the admin will also be able to see some graphs of the submitted information to get a general idea of the patients.
*/
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_controller
{
	
	public function __construct()
	{
		parent:: __construct();
	}

	//admin home page
	public function index(){
		if(!$this->session->userdata('logged_in')){
 			redirect('users/login');
 		}
		$this->load->view('templates/admin_header');
		$this->load->view('admin/adminIndex');
		$this->load->view('templates/admin_footer');
	}


	//main dahsboard for admin
	public function dashboard(){
		if(!$this->session->userdata('logged_in')){
 			redirect('users/login');
 		}
		$this->load->view('templates/admin_header');
		$this->load->view('admin/dashboard');
		$this->load->view('templates/admin_footer');
	}

	//function to show the submitted questionnaires
	public function questionnaire(){
		if(!$this->session->userdata('logged_in')){
 			redirect('users/login');
 		}
		$this->load->view('templates/admin_header');
		$this->load->view('admin/adminQuestionnaire');
		$this->load->view('templates/admin_footer');
	}

	//function to list appications submitted to the admin
	public function list(){
		if(!$this->session->userdata('logged_in')){
 			redirect('users/login');
 		}
		$this->load->view('templates/admin_header');
		$this->load->view('admin/view');
		$this->load->view('templates/admin_footer');
	}
}