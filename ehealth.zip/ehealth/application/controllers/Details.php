<?php
/*
Below is the cladd for the details page that the user would be able to see some information and update it when they need to
*/
defined('BASEPATH') OR exit('No direct script access allowed');
class Details extends CI_controller
{
	
	public function __construct()
	{
		parent:: __construct();
		//$this->load->model('Details_model');
	}

	//loading details view and getting user info

	public function getInfo(){

		//checking if user is logged in, if not, redirect to login page to stop unorthorised access
		if(!$this->session->userdata('logged_in')){
 			redirect('users/login');
 		}
 		//loading the views
		$this->load->view('templates/header');
		$this->load->view('pages/details');
		$this->load->view('templates/footer');
	}
}