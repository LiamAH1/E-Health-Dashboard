<?php
/*
Below is the controller for the pages views, if no page is found it shows an error 404
*/
class Pages extends CI_Controller {

	public function view($page = 'welcome')
	{
		if ( ! file_exists(APPPATH.'views/pages/'.$page.'.php'))
		{
                // Whoops, we don't have a page for that!
			show_404();
		}

        $this->load->view('templates/header');
        $this->load->view('pages/'.$page);
        $this->load->view('templates/footer');
    }
    //loading the welcome page
    public function indexView(){
    	$this->load->view('templates/index_header');
    	$this->load->view('pages/welcome');
    	$this->load->view('templates/index_footer');
    }
}