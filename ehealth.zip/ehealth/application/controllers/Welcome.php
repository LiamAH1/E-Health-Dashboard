<?php
/*
Below is the welcome controller that just handles loading the home page and
checking if the user is logged in
*/
class Welcome extends CI_controller{
	public function __construct(){
		parent:: __construct();
	}

	//showing home page and checking if the logged in session is set to true
	public function home(){
		if(!$this->session->userdata('logged_in')){
 			redirect('users/login');
 		}
		$this->load->view('templates/header');
		$this->load->view('pages/home');
		$this->load->view('templates/footer');
	}
}
