<?php
defined('BASEPATH') OR exit('No direct script access allowed');



$route['home'] = 'Welcome/home';

//routes for all user interaction
$route['users/login'] = 'Users/login';
$route['users/logout'] = 'Users/logout';
$route['users/register'] = 'Users/register';
//route for questionnaire 
$route['questionnaire/submit'] = 'Questionnaire/submit';

//details route
$route['details'] = 'Details/getInfo';

//Admin routes
$route['adminIndex'] = 'Admin/index';
$route['admin/dashboard'] = 'Admin/dashboard';
$route['admin/questionnaire'] = 'Admin/questionnaire';
$route['admin/list'] = 'Admin/list';


$route['default_controller'] = 'Pages/indexView';
$route['(:any)'] = 'Pages/view/$1';



